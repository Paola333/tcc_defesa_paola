enum TypeProfile {
  client,
  worker,
}