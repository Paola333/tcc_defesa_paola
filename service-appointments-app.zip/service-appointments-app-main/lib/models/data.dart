class Data {
  int totalBookings;
  double total;

  Data({
    required this.totalBookings,
    required this.total,
  });
}